#### Project Screen Views :

![Main](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/1.png)
![Register](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/2.png)
![Login](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/3.png)
![Forum](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/4.png)
![Picture](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/5.png)
![Picture-Member](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/5a.png)
![Video](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/6.png)
![Work](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/7.png)
![Maps](https://github.com/ismailtasdelen/basic-panel-project/blob/master/img/8.png)
